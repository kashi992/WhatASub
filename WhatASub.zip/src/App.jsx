import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Home from "./pages/Home";
import Menu from "./pages/Menu.jsx";
import ContactUs from "./pages/ContactUs.jsx";
import About from "./pages/About.jsx";
import Header from "./components/Header.jsx";
import Footer from "./components/Footer.jsx";

function App() {
  const router = createBrowserRouter([
    { path: "/", element: <Home /> },
    { path: "/About", element: <About /> },
    { path: "/ContactUs", element: <ContactUs /> },
    { path: "/Menu", element: <Menu /> },
  ]);

  return (
    <>
      <Header />
      <RouterProvider router={router} />
      <Footer />
    </>
  );
}
export default App;
