import React from "react";
import imageSrc from "../assets/ImagesA/Whatsub_w_text.png";

export const Card = () => {
  return (
    <div>
      <img src={imageSrc} alt="Sandwich" />
    </div>
  );
};
